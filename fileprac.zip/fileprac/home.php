<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registered Users</title>
</head>
<body>
    <h2>Registered Users</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Password</th>
        </tr>
        <?php
        session_start();
        if(isset($_SESSION['registered_users'])) {
            foreach($_SESSION['registered_users'] as $user) {
                echo "<tr>";
                echo "<td>".$user['id']."</td>";
                echo "<td>".$user['name']."</td>";
                echo "<td>".$user['password']."</td>";
                echo "</tr>";
            }
        }
        ?>
    </table>
</body>
</html>
