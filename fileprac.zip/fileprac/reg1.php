<?php
session_start(); 

if(isset($_POST['register'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $npass = $_POST['npass'];
    $cpass = $_POST['cpass'];
    $hobby = $_POST['hobby'];

    $errors = array();

    // Check if ID is empty
    if(empty($id)) {
        $errors[] = "ID is required";
    }

    // Check if Name is empty
    if(empty($name)) {
        $errors[] = "Name is required";
    }

    // Check if Password is empty
    if(empty($npass)) {
        $errors[] = "New Password is required";
    }

    // Check if Confirm Password is empty
    if(empty($cpass)) {
        $errors[] = "Confirm Password is required";
    }

    // Check if Passwords match
    if($npass != $cpass) {
        $errors[] = "Passwords do not match";
    }

    // Check if Hobby is selected
    if($hobby == 'none') {
        $errors[] = "Select a Hobby";
    }

    // Display errors
    if(!empty($errors)) {
        echo "<div><ul>";
        foreach($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul></div>";
    } else {
        // Store user data in session (for demonstration)
        $_SESSION['registered_users'][] = array('id' => $id, 'name' => $name, 'password' => $npass, 'hobby' => $hobby);
        echo "<div>Registration Successful!</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
</head>
<body>
    <div>
        <fieldset>
            <legend>Reg</legend>
        <h2>Registration</h2>
        <form action="#" method="post">
            <div>
                <label for="id">ID:</label> <br>
                <input type="text" id="id" name="id" required>
            </div>
            <div>
                <label for="name">Name:</label><br>
                <input type="text" id="name" name="name" required>
            </div>
            <div>
                <label for="npass">New Password:</label><br>
                <input type="password" id="npass" name="npass" required>
            </div>
            <div>
                <label for="cpass">Confirm Password:</label><br>
                <input type="password" id="cpass" name="cpass" required>
            </div>
            <div>
                <label for="hobby">Hobby:</label><br>
                <select id="hobby" name="hobby">
                    <option value="none">Select Hobby</option>
                    <option value="cricket">Cricket</option>
                    <option value="football">Football</option>
                    <option value="travelling">Travelling</option>
                </select>
            </div>
            <div>
                <input type="submit" value="Register" name="register">
            </div>
        </form>
        <div>
            <a href="login.php">Login</a>
        </div>
    </fieldset>
   
    </div>
</body>
</html>
