<?php
session_start(); 

if(isset($_POST['login'])) {
    $login_id = $_POST['id'];
    $login_name = $_POST['name'];

    // Initialize flag to indicate whether login is successful
    $login_successful = false;

    // Check if there are registered users in the session
    if(isset($_SESSION['registered_users'])) {
        foreach($_SESSION['registered_users'] as $user) {
            if($login_id == $user['id'] && $login_name == $user['name']) {
                // Set flag to indicate successful login
                $login_successful = true;
                break; // Exit the loop since we found a match
            }
        }
    }

    if($login_successful) {
        echo "Login Successful!";
        // Redirect to homepage
        header("Location: home.php");
        exit();
    } else {
        echo "Invalid ID or Name!";
    }
} else {
    echo "Please fill out the login form.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
</head>
<body>
    <fieldset>
        <legend>Login</legend>
        <form action="#" method="post">
            <div>
                <label for="id">ID:</label> <br>
                <input type="text" id="id" name="id" >
            </div>
            <div>
                <label for="name">Name:</label><br>
                <input type="text" id="name" name="name" >
            </div>
            <div>
                <input type="submit" name="login" value="Login">
            </div>
        </form>
        <div>
            <a href="reg1.php">Register</a>
        </div>
    </fieldset>
</body>
</html>
